# part 1
Created webpages which are as follows; homepage.html, aboutus.html, contactus.html; video.html, images.html, sitemap.html and ordernow.html
wrote down the codes for all the webpages with different information according to the pages

# Part 2
Fixed the video on video.html as it was not visible but now it is visible
Rewrote the filenames with spaces and the same abbreviations as the ones that wer saved so that it becomes the same thing
Added the link for style.css to all the pages so that it will be able to run and show css 
Added copyrights to all my webpages as on part 1 not all pages had it
# R.A.K.S SWEETS Website

## Part 3 Implementation

### Changes Made:

#### SEO Implementation
- Added meta descriptions to all pages
- Created `sitemap.xml` for search engine indexing
- Created `robots.txt` for crawl control
- Optimized image alt texts and header structure

#### Form Functionality
- Created `enquiry.html` with service/product enquiry form
- Updated `contact.html` with general contact form
- Implemented client-side validation with JavaScript
- Added AJAX form submission simulation
- Dynamic response system for enquiries

#### Features Added:
- Form validation with error messages
- Responsive form design
- Dynamic form fields based on enquiry type
- Success/response messages
- Mobile-friendly forms

### Change Log:
- [2025-11-07] Part 3: Added SEO optimization (sitemap.xml, robots.txt, meta tags) and form functionality
- [2025-11-08] Implemented form validation with JavaScript
- [2025-11-08] Created enquiry form with dynamic fields
- [2025-11-08] Enhanced contact form with validation
### Order Now Page Enhancements
Added product selection with quantity and size options
Prices displayed per size:
Small: R35
Medium: R45
Large: R55
Extra Large: R65
Glass: R120
Payment methods displayed (bank transfer, cash, email for quotes)
Delivery fee information added

### Contact Form Enhancements
Validated all input fields with JavaScript
Fields include: Full Name, Email, Phone Number, Message Type, Message
Error messages for invalid input
Success message on valid submission
AJAX-like form submission simulation
Responsive form layout for mobile

### Gallery Page & Image Functionality
Created images.html with responsive image grid
Added interactive lightbox for images
Click to enlarge images
Navigate with on-screen arrows or keyboard arrow keys
Close with × button, Esc key, or clicking outside image                        Ensured images load from any page using images/filename.jpg
Added hover effects and responsive styling for all devices
Lightbox implemented with JavaScript

### Navbar & Page Linking
Added horizontal navigation bar on all pages
Links to all main pages (Home, About Us, Contact, Enquiry, Order Now, Images, Sitemap, Video)
Hover effects added via CSS
Active page highlighting implemented for clarity

### References:
- MDN Web Docs - Form Validation
- W3Schools - JavaScript Form Handling
- Google Search Central - SEO Basics
- The IIE Student Materials
