# part 1
Created webpages which are as follows; homepage.html, aboutus.html, contactus.html; video.html, images.html, sitemap.html and ordernow.html
wrote down the codes for all the webpages with different information according to the pages

# Part 2
Fixed the video on video.html as it was not visible but now it is visible
Rewrote the filenames with spaces and the same abbreviations as the ones that wer saved so that it becomes the same thing
Added the link for style.css to all the pages so that it will be able to run and show css 
Added copyrights to all my webpages as on part 1 not all pages had it
